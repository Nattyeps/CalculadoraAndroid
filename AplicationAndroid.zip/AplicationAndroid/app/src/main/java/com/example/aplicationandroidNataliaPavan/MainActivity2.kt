package com.example.aplicationandroidNataliaPavan


import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.aplicationandroidNataliaPavan.Operar.Calculo



class MainActivity2 : AppCompatActivity() {

    var numero1: Int = 0
    var numero2: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


    }

    override fun onResume() {
        super.onResume()
        var nom: String = intent.getStringExtra("nombre").toString()
        var ape: String = intent.getStringExtra("apellido").toString()

        var textViewHola = findViewById<TextView>(R.id.textViewHola)
        textViewHola.text = resources.getString(R.string.hola)


        textViewHola.text = ("Hola" + nom + ape)
        textViewHola.text = textViewHola.text.toString() + nom + ape

    }



    @SuppressLint("WrongViewCast")
    fun buttonIgual() {

        var buttonUno = findViewById<Button>(R.id.buttonUno)
        var buttonDos = findViewById<Button>(R.id.buttonDos)
        var buttonTres = findViewById<Button>(R.id.buttonTres)
        var buttonCuatro = findViewById<Button>(R.id.buttonCuatro)
        var buttonCinco = findViewById<Button>(R.id.buttonCinco)
        var buttonSeis = findViewById<Button>(R.id.buttonSeis)
        var buttonSiete = findViewById<Button>(R.id.buttonSiete)
        var buttonOcho = findViewById<Button>(R.id.buttonOcho)
        var buttonNueve = findViewById<Button>(R.id.buttonNueve)
        var textViewHola = findViewById<EditText>(R.id.textViewHola)
        var textViewResultado = findViewById<TextView>(R.id.textViewResultado)

        var calculo = Calculo(numero1.toString(), numero2.toString(), textViewHola.text.toString())

        textViewResultado.text = calculo.operar()


    }




        override fun onPause() {
            super.onPause()
        }


        override fun onStart() {
            super.onStart()
        }


        override fun onStop() {
            super.onStop()
        }


        override fun onDestroy() {
            super.onDestroy()
        }

    }

