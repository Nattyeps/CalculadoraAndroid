package com.example.aplicationandroidNataliaPavan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }

    fun Acceder(view: View) {
        var editTextNom = findViewById<EditText>(R.id.editTextNom)
        var editTextApe = findViewById<EditText>(R.id.editTextApe)

        var nombre:String = editTextNom.text.toString()

        var apellido: String = editTextApe.text.toString()

        if(nombre.equals(apellido, true)){
            var miIntent = Intent( this, MainActivity2::class.java)
            miIntent.putExtra( "nombre" , nombre)
            miIntent.putExtra( "apellido" , apellido)
            startActivity(miIntent)
            finish()

        }
    }


    override fun onResume() {

        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }


    override fun onStart() {
        super.onStart()
    }


    override fun onStop() {
        super.onStop()
    }


    override fun onDestroy() {
        super.onDestroy()
    }





}


