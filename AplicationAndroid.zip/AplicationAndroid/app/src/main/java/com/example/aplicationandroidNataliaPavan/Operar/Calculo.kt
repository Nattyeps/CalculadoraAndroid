package com.example.aplicationandroidNataliaPavan.Operar

class Calculo {
    var numero1: Int = 0
    var numero2: Int = 0
    var operacion: String = ""

    constructor(numero1: String, numero2: String, operacion: String) {
        this.numero1 = numero1.toInt()
        this.numero2 = numero2.toInt()
        this.operacion = operacion
    }

    private fun sumar(): Int {
        return numero1 + numero2

    }

    private fun restar(): Int {
        return numero1 - numero2

    }

    private fun multiplicar(): Int {
        return numero1 * numero2
    }

    private fun dividir(): String {
        if (numero2 == 0) {
            return "NaN"
        } else {
            return (numero1 / numero2).toString()
        }

    }


    fun operar(): String {
        when (operacion) {
            "sumar" -> return sumar().toString()
            "restar" -> return restar().toString()
            "multiplicar" -> return multiplicar().toString()
            "dividir" -> return dividir()
            else -> return "Operación invalida"

        }
    }

}